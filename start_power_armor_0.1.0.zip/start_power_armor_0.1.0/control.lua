-- Control script: gives player an equipped Power Armor MK2 on player create / respawn.
local equipment_list = {
  "night-vision-equipment",
  "personal-laser-defense-equipment",
  "personal-laser-defense-equipment", -- second copy
  "personal-battery-mk2-equipment",
  "personal-battery-mk2-equipment", -- second copy
  "energy-shield-mk2-equipment",
  "personal-roboport-mk2-equipment",
  "exoskeleton-equipment",
  "fusion-reactor-equipment"
}

-- Utility: try to insert armor and populate its equipment grid if possible.
local function try_equip_armor(player)
  if not (player and player.valid and player.character) then return end
  local armor_inv = player.get_inventory(defines.inventory.character_armor)
  if not armor_inv then return end

  -- If already wearing armor, do nothing.
  local cur = armor_inv[1]
  if cur and cur.valid_for_read then
    -- already has armor
    return
  end

  -- Give the player the power armor item
  local inserted = armor_inv.insert({name = "power-armor-mk2", count = 1})
  if inserted == 0 then
    -- couldn't insert (inventory full) - try to drop to ground then equip
    local pos = player.surface.find_non_colliding_position("character", player.position, 2, 0.5) or player.position
    player.surface.spill_item_stack(pos, {name = "power-armor-mk2", count = 1}, true, player.force, false)
    player.play_sound{path = "utility/cannot_build"}
    return
  end

  local armor_stack = armor_inv[1]
  if not (armor_stack and armor_stack.valid_for_read) then return end

  -- Ensure the equipment grid exists (it should once armor is equipped)
  local grid = armor_stack.grid
  if not grid then
    -- sometimes the grid is not immediately available; defer to next tick via global tracking
    global.pending_players = global.pending_players or {}
    global.pending_players[player.index] = true
    return
  end

  -- Insert equipment, checking prototype existence before each insertion.
  for _, equip_name in ipairs(equipment_list) do
    if game.equipment_prototypes[equip_name] then
      -- try to place; ignore failures (e.g., not enough space)
      local ok, err = pcall(function() grid.put{name = equip_name} end)
      if not ok then
        -- ignore
      end
    end
  end
end

script.on_event(defines.events.on_player_created, function(event)
  local player = game.get_player(event.player_index)
  try_equip_armor(player)
end)

script.on_event(defines.events.on_player_respawned, function(event)
  local player = game.get_player(event.player_index)
  try_equip_armor(player)
end)

-- Check pending players each tick until their armor grid becomes available.
script.on_event(defines.events.on_tick, function(event)
  if not (global and global.pending_players) then return end
  for player_index,_ in pairs(global.pending_players) do
    local player = game.get_player(player_index)
    if player and player.valid then
      local armor_inv = player.get_inventory(defines.inventory.character_armor)
      if armor_inv and armor_inv[1] and armor_inv[1].valid_for_read and armor_inv[1].grid then
        -- populate
        for _, equip_name in ipairs(equipment_list) do
          if game.equipment_prototypes[equip_name] then
            local ok, err = pcall(function() armor_inv[1].grid.put{name = equip_name} end)
          end
        end
        global.pending_players[player_index] = nil
      end
    else
      global.pending_players[player_index] = nil
    end
  end
end)
