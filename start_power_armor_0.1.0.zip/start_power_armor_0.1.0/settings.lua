data:extend({
  {
    type = "bool-setting",
    name = "swpa-auto-equip",
    setting_type = "startup",
    default_value = true,
    order = "a"
  }
})
